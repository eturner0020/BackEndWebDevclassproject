<!DOCTYPE html>
<html>

<!-- the head section -->
<head>
    <title>AUM Student Portal</title>
    <link rel="stylesheet" type="text/css"
          href="/class_project/main.css">
</head>

<!-- the body section -->
<body>
<header>
    <h1>AUM Student Portal</h1>
    <p>Your one stop shop to start your online education</p>
    <nav>
        <ul>
            <li><a href="htdocs/class_project/">Home</a></li>
        </ul>
    </nav>
</header>
