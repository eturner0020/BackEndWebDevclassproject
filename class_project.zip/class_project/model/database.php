<?php

$dsn = 'mysql:host=localhost;dbname=class_project';
$username = 'username';
$password = 'password';

$db = new PDO($dsn, $username, $password);


