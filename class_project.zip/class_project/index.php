<?php include 'webpage_design/header.php'; ?>

<main>
    <nav>
        <h2>Students</h2><!-- comment -->
        <ul>
            <li><a href="student_manager">Create Account</a></li>
            <li><a href="student_login">Login to Your Account</a></li>
            <li><a href="course_manager">View Courses</a></li>
            <li><a href="student_profile_manager">View Student Info</a></li>
        </ul>
    </nav>
</main>
