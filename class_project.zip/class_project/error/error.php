<?php include '../webpage_design/header.php'; ?>
<main>
    <h1>Error</h1>
    <p><?php echo htmlspecialchars($error); ?></p>
</main>

